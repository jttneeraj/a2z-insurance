const DigitConfig = require("./digit.config");
const DigitMapper = require("./digit.mapper");
const DigitExecutorService = require("./digit.executor.service");

class DigitPaymentService {
    async initiatePayment({ payment, proposal, insurerId, payload }) {
        const environment = payload?.environment || "UAT";
        const config = DigitConfig.getConfig(environment);
        const applicationId = payload.applicationId || payload.application_id || payment.insurer_application_id || proposal.insurer_application_id;

        if (!applicationId) {
            const error = new Error("Digit applicationId is required for payment link generation");
            error.insurer_error = true;
            error.insurer = payload?.insurer_code || "DIGIT";
            error.api = "MOTOR_PAYMENT_LINK";
            error.http_status_code = 400;
            throw error;
        }

        const requestPayload = DigitMapper.buildPaymentPayload({ applicationId, payload });

        // const result = await DigitExecutorService.execute({
        //     environment,
        //     insurerId,
        //     insurerCode: payload?.insurer_code || "DIGIT",
        //     apiName: "MOTOR_PAYMENT_LINK",
        //     integrationId: config.paymentIntegrationId,
        //     requestPayload,
        //     logContext: {
        //         lead_id: proposal.lead_id,
        //         quote_request_id: proposal.quote_request_id,
        //         quote_result_id: proposal.quote_result_id,
        //         proposal_id: proposal.id,
        //         payment_id: payment.id,
        //     },
        // });

        const result = await DigitExecutorService.execute({
            insurerId: payment.insurer_id || proposal.insurer_id,
            insurerCode: payload?.insurer_code || "DIGIT",
            quoteRequestId: proposal.quote_request_id,
            quoteResultId: proposal.quote_result_id,
            proposalId: proposal.id,
            paymentId: payment.id,
            apiName: "MOTOR_PAYMENT_INITIATE",
            endpoint: digitConfig.payment.initiateUrl,
            method: "POST",
            
            environment,
            integrationId: config.paymentIntegrationId,
            requestPayload,
            logContext: {
                lead_id: proposal.lead_id,
                quote_request_id: proposal.quote_request_id,
                quote_result_id: proposal.quote_result_id,
                proposal_id: proposal.id,
                payment_id: payment.id,
            },

            payload
        });

        return {
            ...result,
            response_payload: DigitMapper.normalizePaymentResponse(result.response_payload),
            raw_response_payload: result.response_payload,
        };
    }
}
module.exports = new DigitPaymentService();
